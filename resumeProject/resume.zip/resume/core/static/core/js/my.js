function myjs(){
    alert("this is myjs!")
}